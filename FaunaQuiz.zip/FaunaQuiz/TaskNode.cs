﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FaunaQuiz
{
    //represents a node in graph
    public class TaskNode
    {
        private string _taskName;
        private IList<string> _dependentTasks = new List<string>();

        //constructor
        public TaskNode(string taskName)
        {
            if (string.IsNullOrEmpty(taskName.Trim()))
            {
                throw new ArgumentNullException("Task name is required.", nameof(taskName));
            }
            _taskName = taskName;
        }

        public TaskNode(string taskName, string dependentTasks)
        {
            string[] dependentTasksArr = dependentTasks.Split(',');
            _taskName = taskName;
            
            foreach (var item in dependentTasksArr)
            {
                if (!string.IsNullOrEmpty(item.Trim()) && !_dependentTasks.Contains(item) )
                {
                    _dependentTasks.Add(item);
                }
            }
        }

        //Task Name
        public string TaskName
        {
            get
            {
                return _taskName;
            }
        }

        //Dependent Tasks
        public IList<string> DependentTasks
        {

            get
            {
                return _dependentTasks;
            }
        }

        //Add Dependent Task
        public void AddTaskDependency(string dependentTask)
        {
            _dependentTasks.Add(dependentTask);
        }
        
    }
}
