﻿using System.ComponentModel.Design;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace FaunaQuiz
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //console menu  to run tests
            const string menu = """
                Fauna Quiz
                ---------------------
                    1. Example Test1
                    2. Example Test2
                    3. Example Test3
                    4. Example Test4
                    5. Enter task and its dependency
                    6. Exit
                ---------------------
                """;
            Console.WriteLine(menu);
            Console.WriteLine("Enter your choice: ");
            string? input = Console.ReadLine();

            while (input != "6")
            {
                switch (input)
                {
                    case "1":
                        Test1();
                        break;
                    case "2":
                        Test2();
                        break;
                    case "3":
                        Test3();
                        break;
                    case "4":
                        Test4();
                        break;
                    case "5":
                        ReadMultilineInput();
                        break;
                    default:
                        Console.WriteLine("Invalid menu choice.");
                        break;
                }

                Console.WriteLine("Press enter to go back to menu... ");
                Console.ReadLine();
                Console.Clear();
                Console.WriteLine(menu);
                input = Console.ReadLine();
            }
        }

        //read Multiline Input in format NodeValue: edge1,edge2,edge3
        static void ReadMultilineInput()
        {

            //read multiline input
            Console.WriteLine("Enter task and its dependency in format TaskName: Dependent task 1,Dependent task 3,Dependent task 3");
            Console.WriteLine("Example: T: A,B\nA: C\nB: C\nC: D\nAnd press Enter");

            Console.WriteLine("-------------------");
            Console.WriteLine("Enter your input: ");
            string? input = Console.ReadLine();

            TaskGraph taskGraph = new TaskGraph();

            while (!string.IsNullOrEmpty(input))
            {
                //Validate input format T: A,B or T:
                // allow nothing after colon    
                if (string.IsNullOrEmpty(input) || !input.Contains(":"))
                {
                    Console.WriteLine("Input required in correct format. Cannot proceed further .....");
                    return;
                }
                if (!Regex.IsMatch(input, @"^[a-zA-Z0-9]+:$|[a-zA-Z0-9,]+$"))
                {
                    Console.WriteLine("Invalid input format. Cannot proceed further .....");
                    return;
                }
                string[] inputArr = input.Split(':');
                if (inputArr.Length == 0 || inputArr.Length > 2)
                {
                    Console.WriteLine("Invalid input format. Cannot proceed further .....");
                    return;
                }

                string taskName = inputArr[0].Trim();
                string dependentTasks = "";
                if (inputArr.Length == 2)
                {
                    dependentTasks = inputArr[1].Trim();
                }
                
                taskGraph.AddTaskNode(taskName, dependentTasks);
                input = Console.ReadLine();
            }

            Console.WriteLine("Input Graph is:");   
            taskGraph.PrintTaskGraph();
            Console.WriteLine("---------------------");
            Console.WriteLine("Result :");
            taskGraph.TraverseTaskSequenceBFS(taskGraph.GetFirstNode());
            Console.WriteLine("---------------------"); 

        }


        static void Test1()
        {
            //read from console in format NodeValue: edge1,edge2,edge3   
            //example:
            //T: A,B
            //A:
            //B:

            //output:"A B T"  or "B A T" 

            TaskGraph taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            taskGraph.AddTaskNode("A", "");
            taskGraph.AddTaskNode("B", "");
            
            Console.WriteLine("Input Graph is:");
            taskGraph.PrintTaskGraph();
            Console.WriteLine("---------------------");
            Console.WriteLine("Result :");
            taskGraph.TraverseTaskSequenceBFS("T");
            Console.WriteLine("---------------------");
        }
        static void Test2()
        {
            //read from console in format NodeValue: edge1,edge2,edge3   
            //example:
            //T:A,B
            //A:C
            //B:C
            //C:D
            //D:

            //output: D C A B T   

            TaskGraph taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            taskGraph.AddTaskNode("A", "C");
            taskGraph.AddTaskNode("B", "C");
            taskGraph.AddTaskNode("C", "D");
            taskGraph.AddTaskNode("D", "");

            Console.WriteLine("Input Graph is:");
            taskGraph.PrintTaskGraph();
            Console.WriteLine("---------------------");
            Console.WriteLine("Result :");
            taskGraph.TraverseTaskSequenceBFS("T");
            Console.WriteLine("---------------------");
        }

        static void Test3()
        {
            //read from console in format NodeValue: edge1,edge2,edge3   
            //example:
            //T: A,B,C
            //B:D
            //C:F
            //D:F
            //A:D,E,F
            //E:
            //F:

            //output: F C E D B A T

            TaskGraph taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B,C");
            taskGraph.AddTaskNode("B", "D");
            taskGraph.AddTaskNode("C", "F");
            taskGraph.AddTaskNode("D", "F");
            taskGraph.AddTaskNode("A", "D,E,F");
            taskGraph.AddTaskNode("E", "");
            taskGraph.AddTaskNode("F", "");

            Console.WriteLine("Input Graph is:");
            taskGraph.PrintTaskGraph();
            Console.WriteLine("---------------------");
            Console.WriteLine("Result :");
            taskGraph.TraverseTaskSequenceBFS("T");
            Console.WriteLine("---------------------");

        }

        static void Test4()
        {
            //# EXAMPLE 4:
            //        Release: LoadTest,FunctionalTest,VirusScan
            //        LoadTest:Build
            //        FunctionalTest:Build
            //        VirusScan:Build
            //        Build:

            //# One possible outcome for EXAMPLE 4 would be:
            //# Build VirusScan LoadTest FunctionalTest Release

            TaskGraph taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("Release", "LoadTest,FunctionalTest,VirusScan");
            taskGraph.AddTaskNode("LoadTest", "Build");
            taskGraph.AddTaskNode("FunctionalTest", "Build");
            taskGraph.AddTaskNode("VirusScan", "Build");
            taskGraph.AddTaskNode("Build", "");

            Console.WriteLine("Input Graph is:");
            taskGraph.PrintTaskGraph();
            Console.WriteLine("---------------------");
            Console.WriteLine("Result :");
            taskGraph.TraverseTaskSequenceBFS("Release");
            Console.WriteLine("---------------------");

        }
    }
    

}
