﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FaunaQuiz
{

     public class TaskGraph
    {
        private Dictionary<string,TaskNode> _taskNodes = new Dictionary<string,TaskNode>(); //list of task nodes
        private Dictionary<string, bool> visitedNodes = new Dictionary<string, bool>(); //dictionary to store visited nodes
        private Stack<string> _resultStack = new Stack<string>();  // stack to store result in leaf node first order
        public TaskGraph()
        {

        }
        
        //return number of nodes
        public int GetNumberOfNodes()
        {
            return _taskNodes.Count;
        }
        
        //return TaskNode List
        public IList<TaskNode> GetTaskNodes()
        {
            return _taskNodes.Values.ToList();
        }

        //Get First Node
        public string GetFirstNode()
        {
            return _taskNodes.FirstOrDefault().Key;
        }
        
        //add node to graph
        public void AddTaskNode(string taskName , string dependentTasks)
        {
            _taskNodes.Add(taskName.Trim(), new TaskNode(taskName.Trim(), dependentTasks));
        }

        //print input graph
        public void PrintTaskGraph()
        {
            foreach (var node in _taskNodes)
            {
                Console.Write(node.Value.TaskName + " : ");
                foreach (var item in node.Value.DependentTasks)
                {
                    Console.Write(item + " ");
                }
                Console.WriteLine();
            }
        }

        //TraverseDependentTaskSequence : Breath First Travsersal
        public void TraverseTaskSequenceBFS(string taskName)
        {
            //initialize visited nodes and stack result
            visitedNodes = new Dictionary<string, bool>();
            _resultStack = new Stack<string>();

            visitedNodes.Add(taskName, false);  //add root node

            //find if have not visited node
            while (visitedNodes.ContainsValue(false))
            {
                var notVisitedTaskName = visitedNodes.FirstOrDefault(x => x.Value == false).Key;
                visitedNodes[notVisitedTaskName] = true;  //mark node as visited
                _resultStack.Push(notVisitedTaskName); //push node to result stack
                AddDependentTasksToTraverse(notVisitedTaskName);
            }

            PrintTraverseResult();
        }


        #region "private methods"
        private void AddDependentTasksToTraverse(string taskName)
        {
            if (_taskNodes.ContainsKey(taskName) && _taskNodes[taskName].DependentTasks.Count > 0)
            {
                foreach (var item in _taskNodes[taskName].DependentTasks)
                {
                    if (!visitedNodes.ContainsKey(item))
                    {
                        visitedNodes.Add(item, false);
                    }
                }
            }
        }


        //print result stack    
        private void PrintTraverseResult()
        {
            while (_resultStack.Count > 0)
            {
                Console.Write(_resultStack.Pop() + " ");
            }

            Console.WriteLine();
        }

        #endregion
    }
}
