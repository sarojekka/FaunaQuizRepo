﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FaunaQuiz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FaunaQuiz.Tests
{
    [TestClass]
    public class TaskNodeTests
    {
        [TestMethod("Test Exception for Constructor without empty parameters")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TaskNodeTest()
        {
            TaskNode taskNode = new TaskNode("");
        }

        [TestMethod("Create Task Node with just name")]
        public void CreateTaskNodeTest()
        {
            TaskNode taskNode = new TaskNode("T");
            Assert.IsNotNull(taskNode);
            Assert.AreEqual("T", taskNode.TaskName);
            Assert.AreEqual(0, taskNode.DependentTasks.Count);
            
        }

        [TestMethod("Create Task Node with name and dependecy task")]
        public void CreateTaskWithDependencyTest()
        {
            TaskNode taskNode = new TaskNode("T", "A,B");   
            Assert.IsNotNull(taskNode); 
            Assert.AreEqual("T", taskNode.TaskName);
            Assert.AreEqual(2, taskNode.DependentTasks.Count);
            Assert.AreEqual("A", taskNode.DependentTasks[0]);
            Assert.AreEqual("B", taskNode.DependentTasks[1]);
            
        }


        [TestMethod("Add dependecy task")]
        public void AddTaskDependencyTest()
        {
            TaskNode taskNode = new TaskNode("T", "A,B");
            
            Assert.IsNotNull(taskNode);
            Assert.AreEqual("T", taskNode.TaskName);
            Assert.AreEqual(2, taskNode.DependentTasks.Count);
            Assert.AreEqual("A", taskNode.DependentTasks[0]);
            Assert.AreEqual("B", taskNode.DependentTasks[1]);

            taskNode.AddTaskDependency("C");
            Assert.AreEqual(3, taskNode.DependentTasks.Count);
            Assert.AreEqual("C", taskNode.DependentTasks[2]);

        }
    }
}