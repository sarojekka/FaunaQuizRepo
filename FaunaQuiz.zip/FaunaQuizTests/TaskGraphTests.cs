﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FaunaQuiz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FaunaQuiz.Tests
{
    [TestClass]
    public class TaskGraphTests
    {
        [TestMethod("Create instance")]
        public void TaskGraphTest()
        {
            var taskGraph = new TaskGraph();
            Assert.IsNotNull(taskGraph);
        }

        [TestMethod("Verify node count")]
        public void GetNumberOfNodesTest()
        {
            var taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            taskGraph.AddTaskNode("A", "C");
            taskGraph.AddTaskNode("B", "C");
            int taskNodeCount = taskGraph.GetNumberOfNodes();

            Assert.IsNotNull(taskGraph);
            Assert.AreEqual(3, taskNodeCount);

        }

        [TestMethod("Verify node name list")]
        public void GetTaskNodesTest()
        {
            var taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            taskGraph.AddTaskNode("A", "C");
            taskGraph.AddTaskNode("B", "C");
            IList<TaskNode> taskNodes = taskGraph.GetTaskNodes();

            Assert.IsNotNull(taskGraph);
            Assert.AreEqual(3, taskNodes.Count);
            Assert.AreEqual("T", taskNodes[0].TaskName);    
            Assert.AreEqual("A", taskNodes[1].TaskName);    
            Assert.AreEqual("B", taskNodes[2].TaskName);    
        }


        [TestMethod("Verify node dependent Task list")]
        public void GetTaskNodesDependentTaskTest()
        {
            var taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            taskGraph.AddTaskNode("A", "C");
            taskGraph.AddTaskNode("B", "C");
            IList<TaskNode> taskNodes = taskGraph.GetTaskNodes();

            Assert.IsNotNull(taskGraph);
            Assert.AreEqual(3, taskNodes.Count);
            Assert.AreEqual("T", taskNodes[0].TaskName);
            Assert.AreEqual("A", taskNodes[1].TaskName);
            Assert.AreEqual("B", taskNodes[2].TaskName);
            Assert.AreEqual(2, taskNodes[0].DependentTasks.Count);  
            Assert.AreEqual(1, taskNodes[1].DependentTasks.Count);  
            Assert.AreEqual(1, taskNodes[2].DependentTasks.Count);
            Assert.AreEqual("A", taskNodes[0].DependentTasks[0]);   
            Assert.AreEqual("B", taskNodes[0].DependentTasks[1]);   
            Assert.AreEqual("C", taskNodes[1].DependentTasks[0]);   
            Assert.AreEqual("C", taskNodes[2].DependentTasks[0]);
        }


        [TestMethod()]
        public void GetFirstNodeTest()
        {
            var taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            taskGraph.AddTaskNode("A", "C");
            taskGraph.AddTaskNode("B", "C");
            string firstNode = taskGraph.GetFirstNode();

            Assert.IsNotNull(taskGraph);
            Assert.IsNotNull(firstNode);

        }

        [TestMethod()]
        public void AddTaskNodeTest()
        {
            var taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            Assert.IsNotNull(taskGraph);
            Assert.AreEqual(1, taskGraph.GetNumberOfNodes());
            Assert.AreEqual("T", taskGraph.GetTaskNodes()[0].TaskName);
            Assert.AreEqual(2, taskGraph.GetTaskNodes()[0].DependentTasks.Count);
            Assert.AreEqual("A", taskGraph.GetTaskNodes()[0].DependentTasks[0]);
            Assert.AreEqual("B", taskGraph.GetTaskNodes()[0].DependentTasks[1]);
        }

        [TestMethod("Print Graph")]
        public void PrintTaskGraphTest()
        {
            var taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            Assert.IsNotNull(taskGraph);
            
        }

        [TestMethod("Traverse Graph")]
        public void TraverseTaskSequenceBFSTest()
        {
            var taskGraph = new TaskGraph();
            taskGraph.AddTaskNode("T", "A,B");
            taskGraph.AddTaskNode("A", "C");
            taskGraph.AddTaskNode("B", "C");
            Assert.IsNotNull(taskGraph);
        }

       
    }
}